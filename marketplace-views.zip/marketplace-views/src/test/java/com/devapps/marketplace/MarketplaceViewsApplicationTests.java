package com.devapps.marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketplaceViewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
