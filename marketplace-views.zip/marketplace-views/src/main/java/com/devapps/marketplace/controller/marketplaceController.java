package com.devapps.marketplace.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.devapps.marketplace.transaction.ITransaction;

@Controller
public class marketplaceController {
	private ITransaction<HttpServletRequest, ModelAndView> registerProduct;
	
	@Autowired
	public marketplaceController(@Qualifier("RegisterProduct")ITransaction<HttpServletRequest, ModelAndView> registerProduct) {
		this.registerProduct=registerProduct;
	}
	
	@RequestMapping(value = "/home")
	public ModelAndView home(ModelAndView model, HttpServletRequest request) {
		try {
			ModelAndView modelAndView = new ModelAndView();
			
			modelAndView = registerProduct.action(request);
	
			return modelAndView;
		} catch (Exception e) {
			return null;
		}

		
	}

}
