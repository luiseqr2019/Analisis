package com.devapps.marketplace.registerproduct;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.devapps.marketplace.transaction.ITransaction;

@Service("RegisterProduct")
public class RegisterProduct implements ITransaction<HttpServletRequest, ModelAndView>{

	@Override
	public ModelAndView action(HttpServletRequest request) {
		ModelAndView model=new ModelAndView();
		//model.addObject("action", "indexPsRefund");
		model.setViewName("registerProduct");
		return model;
	}
	

}
