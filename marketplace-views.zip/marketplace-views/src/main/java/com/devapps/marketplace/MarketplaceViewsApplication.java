package com.devapps.marketplace;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SpringBootApplication
@SpringBootConfiguration
@EnableConfigurationProperties
@ComponentScan(basePackages = { "com.devapps" })
@EnableAutoConfiguration(exclude = {ErrorMvcAutoConfiguration.class})
public class MarketplaceViewsApplication extends WebMvcConfigurerAdapter{

	public static void main(String[] args) {
		try {
			System.setProperty("hostname", InetAddress.getLocalHost().getHostName());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SpringApplication.run(MarketplaceViewsApplication.class, args);
	}

}
