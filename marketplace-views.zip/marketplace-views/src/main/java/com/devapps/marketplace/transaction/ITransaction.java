package com.devapps.marketplace.transaction;

public interface ITransaction<I, O> {
	public O action(I request);
}
