var count = 0;
var lang = "es";
var count2 = 0;
var count3 = [0,0,0,0,0,0,0,0,0,0]; //llenamos con 0 el array que llevara la cuenta de las variables.
var infopago = [];
var myMap = new Map();
var totalAcumulado=0;
var totalGlobal=0;
var totalSumado=0;
var firstTime=true;
var numberDecimals=2;
var path = "/payment";
var idElementFocus="";


$(document).ready(function(){
	$("#exentIva").change(function(event){
		totalGlobal=0;		
		firstTime=true;
		var isChecked = document.getElementById("exentIva").checked;
			$.ajax({
				type: "GET",
				url: "/payment/exentIvaMiles/"+isChecked+"?rnd="+new Date().getTime(),			  
			}).done(function(data,textStatus, jqXHR ) {
				
				
				var span1= "<span>";
				var span4= "</span>";
				var span3= data.subTotal+' '+data.total;
				$("#emdTotal").html(span3);
				
				
				if(isChecked){
					$("#taxSpan").hide();
					if($("#sum-exenIvaTemp").length){
						$("#sum-exenIvaTemp").show();
					}else{
						$("#tax").append("<span id='sum-exenIvaTemp'>0</span>");	
					}
					
				}else{
					$("#sum-exenIvaTemp").hide();
					$("#taxSpan").show();
					
				}
    			$("#total").html(data.total);
			});
			$("#formasPago").prop('disabled', false);
			myMap = new Map();
			$("#formPagoDiv").empty();
			updateCantidadAcumulada();
	});
	
	$("#selectCco").hide();
	
	$("select.e1").select2();
	$('select.req').next().addClass("req");
	
	
	var textoEmd=$("#emdText").text();
	textoEmd=textoEmd.replace("<value>",$(".quantityMilesClass").html());
	textoEmd.replace
	$("#emdText").text(textoEmd);
	var claseRadio = $('input[name=factura]:nth(0)').attr('class');
	if (claseRadio !== undefined){
		var sClaseRadio = claseRadio.split(" ");
	}else {
		var sClaseRadio = "";
	}
	
	if(sClaseRadio[0] == "validate"){
		$('input:radio[name=factura]:nth(0)').attr('checked',true);
	}
	
	
	//tipo_credito
	//$(".credito").hide();
	$("#factura").click(function(){
  	$(".factura" ).show();
	$(".credito").hide();
	});
	$("#credito").click(function(){
  	$(".credito" ).show();
	$(".factura").hide();
	});
	
	
	$(document).on( "blur", "input[name='CCnumTarjeta1'],input[name='CCnumTarjeta2'],input[name='CCnumTarjeta3'],input[name='CCnumTarjeta4']", function(event) {
		var $th = $(this);
		if($th.val().length<13){
			nameField=$(this).closest("div").prop("id");
			var errorCustom=A3.replace("<NombreCampo>",nameField);
			$("#lblmsgerr").html(errorCustom);
			idField=$(this).prop("id");
			idElementFocus=idField;
			$th.val("");
			$.colorbox({inline:true, href:$("#errorPop")});
		//	alert('Se ha alcanzado el máximo de formas de pago permitidas para el tipo seleccionado');
			return false;
		}
	});
	
	
	$("#pagos option").each(function(){
		   if ($(this).attr('value') != " "){
			   infopago[count2] = $(this).attr('value')
			   count2 += 1;
		   }
		});
	
	$( "#iata" ).change(function() {
			
		var iata = $("#iata").val();
		//iata["iata"] = $("#iata").val();
		$("#exentIva").prop('checked', false);
		
			$.ajax({
			    type: "GET",
			    url: "/payment/iata/"+iata+"?rnd="+new Date().getTime(),			  
			}).done(function(data,textStatus, jqXHR ) {
				if(data){
					var elementCurrency='<strong>'+data.currency+'</strong>';
					numberDecimals=data.decimals;
					$("#psCurrency").html(elementCurrency);
					$("#quantity").html(data.quantity);
					$("#subtotal").html(data.subtotal);
					$("#tax").html("<span id='taxSpan'>"+data.tax+"</span>");
					if(data.tax!=null && data.tax>0){
							$(".divIva").show();
						}else{
							$(".divIva").hide();
						}
					$("#total").html(data.total);
					totalGlobal=data.total;
					var emdTotal=data.currency+" "+data.total;
					$("#emdTotal").html(emdTotal);
					$("#emdComplement").html("("+data.serviceType+")");
					var textoEmd=$("#emdText").text();
					textoEmd=textoEmd.replace("<value>",data.total);
					$("#emdText").text(textoEmd);
					if(data.textToChangeCurrency){
						$("#currencyChange").html(data.textToChangeCurrency);
					}else{
						$("#currencyChange").empty();
					}
					$("#formasPago").prop('disabled', false);
					myMap = new Map();
					$("#formPagoDiv").empty();
					updateCantidadAcumulada();
				}
			})
			 .fail(function( jqXHR, textStatus, errorThrown ) {
		        console.log( "La solicitud a fallado: " +  textStatus);	
			});
			$("#waiver").prop("checked", false);
			$("#Autoriza_CCO").hide();
			$("#emdDiv").show();
			$("#payFormsDiv").show();
		
	});
	
	$( "#pspaises" ).change(function() {
		
		var iata = $("#pspaises").val();
		//iata["iata"] = $("#iata").val();
		var iataArray=iata.split("-");
		iata=iataArray[0];
		countryCode=iataArray[1];
			$.ajax({
			    type: "GET",
			    url: "/payment/iata/"+iata+"?rnd="+new Date().getTime(),			  
			}).done(function(data,textStatus, jqXHR ) {
				if(data){
					var elementCurrency='<strong>'+data.currency+'</strong>';
					$("#psCurrency").html(elementCurrency);
					$("#quantity").html(data.quantity);
					$("#subtotal").html(data.subtotal);
					$("#tax").html(data.tax);
					$("#total").html(data.total);
					if(data.textToChangeCurrency){
						$("#currencyChange").html(data.textToChangeCurrency);
					}else{
						$("#currencyChange").empty();
					}
					
					var i=1;
					$('#numCuotas').empty();
					for(i=i;i<=data.installments;i++){
						$('#numCuotas').append($('<option>', {
						    value: i,
						    text: i
						}));
					}
					
					
					if(countryCode!="SV"){
						$("#faturaCCF").hide();
					}else{
						$("#faturaCCF").show();
						if(parseFloat(data.total)>=200 ){
							$("#razfac").addClass( "req" );
							$("#direfac").addClass( "req" );
							$("#duifac").addClass( "req" );
						}
					}
					
				}
			})
			 .fail(function( jqXHR, textStatus, errorThrown ) {
		        console.log( "La solicitud a fallado: " +  textStatus);	
			});

		
	});
	

	$(document).on( "focusout", "input[name='dirBen']", function(event) {
		var $th = $(this);
		var format1 = '[a-zA-Z]+';
		var format2 = '[0-9]+';
		var re1 = new RegExp(format1,"g");
		var re2 = new RegExp(format2,"g");
		if(!re1.test($th.val())){
			$th.val("");
			$("#lblmsgerr").html('la direccion almenos tiene quetener una letra');
			$.colorbox({inline:true, href:$("#errorPop")});
		}else{
			if(!re2.test($th.val())){
				$th.val("");
				$("#lblmsgerr").html('la direccion almenos tiene quetener un numero');
				$.colorbox({inline:true, href:$("#errorPop")});
			}
		}
			
	});
	
	$(document).on( "change", "select[name='pais']", function() {
		$("select[name*='estado'] option:not(:first)").remove();
		$(".newState, .newState + .select2").remove();
		$.ajax({
			  url: path+"/states/"+$("select[name='pais']").val()+ "/"+lang+"?rnd="+new Date().getTime()
			}).done(function(data) {				
				$("input[name='estado']").val('');
				if(data.length> 0){
					dropDwn = "<select class='newState e1 populate w-240 req'>";
					dropDwn += "<option value=' '></option>";
					for(var i = 0; i< data.length; i++){
						dropDwn += "<option value='"+data[i].id+"'>"+data[i].name+"</option>";
						//$("select[name*='estado']").append("<option value='"+data[i].id+"'>"+data[i].name+"</option>");
					}
					dropDwn += "</select>";
					$("input[name='estado']").after(dropDwn);
					$("input[name='estado']").hide();
					$(".newState").select2();
				}
				else{
					$("input[name='estado']").show();
				}
			});
		
		//otro ajax para obtener si es requerido el codigo postal y el formato
		$.ajax({
			  url: path+"/zipCode/"+$("select[name*='pais']").val()+"?rnd="+new Date().getTime()
			}).done(function(data) {
				if(data!= null && data.countryCode != null){
					if(data.required == 'Y'){
						$("input[name='codigoPos']").addClass("req");
						$("input[name='codigoPos']").parent().prev().html("* "+$("input[name='codigoPos']").parent().prev().html() );
						//$("input[name='codigoPos']").attr("format2",$("input[name='codigoPos']").attr("format"));
						$("input[name='codigoPos']").attr("format2",data.format);
					}
					else{
						$("input[name='codigoPos']").parent().prev().html($("input[name='codigoPos']").parent().prev().html().replace("* ", ""));
						$("input[name='codigoPos']").removeClass("req");
						$("input[name='codigoPos']").attr("format2", "null");
						$("input[name='codigoPos']").removeClass("error");
					}
				}
				else{
					$("input[name='codigoPos']").parent().prev().html($("input[name='codigoPos']").parent().prev().html().replace("* ", ""));
					$("input[name='codigoPos']").removeClass("req");
					$("input[name='codigoPos']").attr("format2", "null");
					$("input[name='codigoPos']").removeClass("error");
					//$("input[name='codigoPos']").attr("format",$("input[name='codigoPos']").attr("format2"));
				}
			});
	});
	
	
	
	//funcion para retornar las formas de pago y construir el formulario en base a la opcion elegida 
	$("#formasPago").click(function(evento){				
		//Se revisa el json a mostrar con la forma de pago especifica
		var fop=$("select[name*='fop']").val()+"?rnd="+new Date().getTime();
		$.ajax({
			
		    type: "GET",
		    dataType: "json",
		    url: "/payment/psFormOfPayment/"+fop,			  
			}).done(function(data,textStatus, jqXHR ) {
				//console.log(data.fields.length);
				var fopCode = data.code;
				var maxfop = data.maxFop;
				var nameFop = data.name;
				
				var countTemp=myMap.get(fopCode);
				if(countTemp){
					if(countTemp>=maxfop){
						$("#lblmsgerr").html(A2);
						$.colorbox({inline:true, href:$("#errorPop")});
					//	alert('Se ha alcanzado el máximo de formas de pago permitidas para el tipo seleccionado');
						return false;
					}else{
						
						if(count>=5){
							$("#lblmsgerr").html(A1);
							$.colorbox({inline:true, href:$("#errorPop")});
							//alert('Se ha alcanzado el máximo de formas de pago permitidas');
							return false;
						}else{
							count += 1;
							countTemp+=1;
							myMap.set(fopCode,countTemp);
						}
					}
					
				}else{
					myMap.set(fopCode,1);
					countTemp=1;
					count += 1;
				}
				var namediv=fopCode+"-"+countTemp;
				
				//se crean los formularios en base a la forma de pago
				$(formPagoDiv).append('<div id='+namediv +' style = "border:1px dashed; padding-left: 5px;" info-pago="'+ fopCode +'" canal="CTO">');
				$("#"+namediv).append('<div class="clear"></div>');					    
			    $("#"+namediv).append('<div class="w-140 f-left pass-label"><p><strong>FORMA DE PAGO:</strong></p></div>');
			    $("#"+namediv).append('<div class="w-140 f-left pass-label"><p><strong>' + data.name + '</strong></p></div>');
			    $("#"+namediv).append('<div class="clear"></div>');		
			    labelTemp="";
				for(var i = 0; i< data.fields.length; i++){					
					var labelfield = data.fields[i].label; // name label					
					var idfield = data.fields[i].code; // id del field									
					var namefield = data.fields[i].field; // name del field					
					var fieldtype = data.fields[i].type; //field type					
					var fieldreq = data.fields[i].required; // field required
					var fieldType= data.fields[i].type;
					//var minchars = data.fields[i].minchars; //field min chars
					var format= data.fields[i].format
					var maxchars = data.fields[i].maxLength; //field max chars					
					var order = data.fields[i].order; //field order	
					
					//valido si el campo es requerido
					if (fieldreq=="Y")
						claseField = "input-dyn w-240 req";
					else
						claseField = "input-dyn w-240";							
					
					var validadorSameField="N";
					if(labelTemp===labelfield){
					}else{
						labelTemp=labelfield
						$("#"+namediv).append('<div id="nameField" class="w-140 f-left pass-label">'+ labelfield +'</div>');
					}
					
					
				    //agregar campo					
				    //$("#"+namediv).append('<div id="nameField" class="w-140 f-left pass-label">'+ labelfield +'</div>');	
				    
				    var valueCantidad="";
				    var onchange="";
				    var classCantidad=""
				    var keypress="";
				    if(namefield==="cantidad"){
				    	
				    	classCantidad=" inputCantidad"
				    	var total=$("#total").html();
				    	keypress=" onkeypress='return isNumberKey(event)'";
				    	var tempTotal=0;
				    	if(totalGlobal==0 && firstTime ){
				    		tempTotal=total;
				    		totalGlobal=total;
				    		totalAcumulado=total;
				    		firstTime=false;
				    	}else{
				    		tempTotal=totalGlobal-totalAcumulado;
				    		tempTotal=tempTotal.toFixed(numberDecimals);
				    	}
				    	
				    	if(tempTotal<=0){
				    		tempTotal="";
				    	}
				    	valueCantidad="value='"+tempTotal+"' ";
				    	onchange=" onchange='changeCantidad(this.id)'";
				    }
				    
				    
				    if(namefield==="fecExpMes" || namefield==="fecExpAnio" ){
				    	if(namefield==="fecExpMes"){
				    		//Construyendo los meses
				    		var optionMonths='<option value="">Mes</option>';
				    		for (var j = 1; j <= 12; j++){
				    			optionMonths=optionMonths+'<option value="'+j+'">'+j+'</option>';
				    		}
				    		
				    		$("#"+namediv).append('<div style="float:left" id="'+labelfield+'"><select class="req e1 populate w-114 f-left select2-hidden-accessible " style="width: 120px;" name="' + fopCode+namefield + countTemp + '" id="' + fopCode+ namefield + countTemp + '">'+optionMonths+'</select></div>');
				    		
				    	}
				    	if(namefield==="fecExpAnio"){
				    		
				    		var d = new Date();
				    	    var year = d.getFullYear();
				    	    var optionYear='<option value="">Año</option>';
				    		for (var j = year; j <= (year + 10); j++){
				    			optionYear=optionYear+'<option value="'+j+'">'+j+'</option>';
				    		}
				    		
				    		$("#"+namediv).append('<div id="'+labelfield+'"><select class="req e1 no-txt populate w-114 f-right select2-hidden-accessible" style="width: 100px;float:left" name="' + fopCode+namefield + countTemp + '" id="' + fopCode+ namefield + countTemp + '">'+optionYear+'</select></div>');
				    	}
				    	$("select.e1").select2();
				    }else{
				    	$("#"+namediv).append('<div  id="'+labelfield+'"><input type="text" style="width: 240px;" '+valueCantidad+onchange+keypress+'   class="' + claseField +classCantidad+ '" name="' + fopCode+namefield + countTemp + '" id="' + fopCode+ namefield + countTemp + '" format="'+format+'" orden="'+ 1 +'" maxlength="'+ maxchars +'" /></div>');
				    }
				   
				}
				$("#"+namediv).append('<input type="hidden" style="width: 240px;" value="'+ fopCode+ countTemp+'"  name="'+fopCode+countTemp+'"   />');
				$("#"+namediv).append('<input type="button" id=btRemove'+countTemp+'" name=btRemove'+countTemp+' value="Eliminar" button-name="btRemove" style="float:right;" />');
				
				$("#"+namediv).append('<div class="clear"></div>');
				$("#"+namediv).append('</div>');
			
				updateCantidadAcumulada();					
				
			 })
			 .fail(function( jqXHR, textStatus, errorThrown ) {
			     if ( console && console.log ) {
			         console.log( "La solicitud a fallado: " +  textStatus);	
					 $("#lblmsgerr").html("Seleccione una forma de pago");
			         $.colorbox({inline:true, href:$("#errorPop")});
				}
			
			});
	   });
	
	   $("#waiver").click(function() {  
	    var option = false;
		    if($("#waiver").is(':checked')){
				$("#Autoriza_CCO").show();
				$("#emdDiv").hide();
				$("#payFormsDiv").hide();
				option = true;
					
		   } else {
				$("#Autoriza_CCO").hide();
				$("#emdDiv").show();
				$("#payFormsDiv").show();
				option = false;
		   }
		    $.ajax({
			    type: "GET",
			    url: "/payment/waiverApply/"+ option+"?rnd="+new Date().getTime(),			  
			}).done(function(data,textStatus, jqXHR ) {
				if(data){
					var elementCurrency='<strong>'+data.currency+'</strong>';
					numberDecimals=data.decimals;
					$("#psCurrency").html(elementCurrency);
					$("#quantity").html(data.quantity);
					$("#subtotal").html(data.subtotal);
					$("#tax").html(data.tax);
					$("#total").html(data.total);
					totalGlobal=data.total;
					var emdTotal=data.currency+" "+data.total;
					$("#emdTotal").html(emdTotal);
					$("#emdComplement").html("("+data.serviceType+")");
					var textoEmd=$("#emdText").text();
					textoEmd=textoEmd.replace("<value>",data.total);
					$("#emdText").text(textoEmd);
					if(data.textToChangeCurrency){
						$("#currencyChange").html(data.textToChangeCurrency);
					}else{
						$("#currencyChange").empty();
					}
					$("#formasPago").prop('disabled', false);
					myMap = new Map();
					$("#formPagoDiv").empty();
					updateCantidadAcumulada();
				}
			})
	   
	   }); 	
	
	$(document).on( "submit", "form", function() {		
		estado = false;
		element="";
		idElementFocus="";
		var nameField="";
		var idField="";
		//addErrorClass(".req");
		$(".req").each( function( index ) {
		  if(($(this).attr("class").indexOf('select2-container') == -1 && ($(this).val() == null || $(this).val().trim() == "")) || 
			($(this).attr("class").indexOf('select2-container') != -1 && ($(this).prev().val() == null || $(this).prev().val().trim() == "")))	{	

			  if(!estado && $(this).is(':visible')) {
				  element = this;
				  estado =  true;
			  }

			  var elementType = $(this).prop('type');
			  if(!elementType.indexOf("select")===-1){
				  $($(this).data('select2').$container).addClass('error')
				  $($(this).data('select2').$container).focus();
			  }else{
				  $(this).addClass("error");  
			  }
			  
			 
			  
			  
			  if($(this).prop("name")){
				  nameField=$(this).closest("div").prop("id");
				//  var nameField=$("#"+id).find("#nameField").text();
				//  alert(id);
				  
				  //nameField=$(this).prop("name");
				  idField=$(this).prop("id");
				  return false;
			  }
		  }
		  else $(this).removeClass("error");
		});		
		
		
		
		 if(estado) {

			$("#"+idField).addClass("error");
			
			
			
			var errorCustom=A7.replace("<NombreCampo>",nameField);
			$("#lblmsgerr").html(errorCustom);
			$.colorbox({open:true,inline:true, href:$("#errorPop")});
			idElementFocus=idField;
			 $("#" + idField).attr('autofocus','autofocus');
			return false;
		 }
		 else{
			 if(!$("#waiver").is(':checked')){
			 
				 if(totalAcumulado<totalGlobal){
					dif=totalGlobal-totalAcumulado;
					dif=dif.toFixed(numberDecimals);
					messageReplace=A4.replace("<diferencia>",dif);
					messageReplace=messageReplace.replace("<Moneda>"," "+$("#psCurrency").text());
					$("#lblmsgerr").html(messageReplace);
					$.colorbox({inline:true, href:$("#errorPop")});
					return false;
				 }
				 
				 if(totalAcumulado>totalGlobal){
					 	dif=(totalGlobal-totalAcumulado)*-1;
						dif=dif.toFixed(numberDecimals);
						messageReplace=A4.replace("<diferencia>",dif);
						messageReplace=messageReplace.replace("<Moneda>"," "+$("#psCurrency").text());
						$("#lblmsgerr").html(messageReplace);
						$.colorbox({inline:true, href:$("#errorPop")});
						return false;
				 }
			 }
			 if(! $("input[name='confirmContinue']").is(':checked')){
				$("#lblmsgerr").html(A8);
				$.colorbox({inline:true, href:$("#errorPop")});
				return false;
			 }
			 
			 

			if($(this).attr("action").indexOf('process') != -1){
				$(".continueOD").attr("disabled", "disabled");
			}
			
			var submitActions = ["continueCto","continueCtoRedeem","continueCapl","continueCaplRedeem","continueCtoTicketRedeem","continueComRedeem", "obtenerDatosTarjetaPs"];
			var formAction=$(this).attr("action")!=null?$(this).attr("action").replace("/payment/",""):"";
			showIntermediatePage(submitActions,formAction,"notRedeem");
		 }		 		
	});
	

		$(document).on( "keydown", "input[type='text']:not(input.inputCantidad,input[name='email'])", function(event) { 
			
			if(event.which !=127 && event.which > 46){ //teclas de control
				var $th = $(this);
				if($th.attr("format") != "null" && $th.attr("format") != undefined){
					
					var format = $th.attr("format");
					var re = new RegExp(format,"g");
					if(!re.test(event.key))
						 event.preventDefault();
				}
			
		}
		});
		
		
//		$(document).on( "focusout", "input[type='text']:not(input.inputCantidad,input[name='email'])", function(event) {
//				var $th = $(this);
//				if($th.attr("format") != "null" && $th.attr("format") != undefined){
//					var format = $th.attr("format");
//					var valor = $th.attr("value");
//					var re = new RegExp(format,"g");
//					
//					if(!re.test(valor)){
//						$th.val("");
//						$("#lblmsgerr").html('El formato no es correcto');
//						$.colorbox({inline:true, href:$("#errorPop")});
//					}
//				
//				}
//			
//			});
//		
		$(document).on( "blur", "input[type='text']:not(input.inputCantidad,input[name='email'])", function(event) {
						var $th = $(this);
						if($th.attr("format") != "null" && $th.attr("format") != undefined){
							
							var format = $th.attr("format");
							var re = new RegExp(format,"g");
							var valueEvaluate=$th.val();
							valueEvaluate=valueEvaluate.replace(/[-[\]{}()*+?.,\\^$|#]/g, '');
							$th.val(valueEvaluate);
							valueEvaluate=$th.val();
							var re = new RegExp(format,"g");
							if(!re.test(valueEvaluate)){
								$th.val("");
							}
							
							
						}
			});
		
		$(document).on( "focusout", "input[name='email']", function(event) {
			var $th = $(this);
			if($th.attr("format") != "null" && $th.attr("format") != undefined){
				var format = $th.attr("format");
				var re = new RegExp(format,"g");
				if(!re.test($th.val())){
					$th.val("");
					$("#lblmsgerr").html('El formato de correo no es correcto');
					$.colorbox({inline:true, href:$("#errorPop")});
				}
			}
		});
});


function isNumberKey(evt)
{
   var charCode = (evt.which) ? evt.which : evt.keyCode;
   if (charCode != 46 && charCode > 31 
     && (charCode < 48 || charCode > 57))
      return false;

	
   if (charCode == 46 && evt.srcElement.value.split('.').length>1) 
   	{
	   return false; 
	}
   
   return true;
}


function changeCurrency(currency){
	$.ajax({
	    type: "GET",
	    url: "/payment/switch/"+currency+"?rnd="+new Date().getTime(),			  
	}).done(function(data,textStatus, jqXHR ) {
		if(data){
			$("#exentIva").prop('checked', false);
			var elements = document.getElementsByClassName("inputCantidad");
			
			var name="";
			var quantities="";
			for (var i = 0; i < elements.length; i++) {
				name=elements[i].name;
				id=elements[i].id;
				valor=$("input[name="+name+"]").val("");
			}
			var elementCurrency='<strong>'+data.currency+'</strong>';
			$("#psCurrency").html(elementCurrency);
			$("#quantity").html(data.quantity);
			$("#subtotal").html(data.subtotal);
			$("#tax").html(data.tax);
			$("#total").html(data.total);
			totalGlobal=data.total;
			
			
			var emdTotal=data.currency+" "+data.total;
			$("#emdTotal").html(emdTotal);
			if(data.textToChangeCurrency){
				$("#currencyChange").html(data.textToChangeCurrency);
			}else{
				$("#currencyChange").empty();
			}
			updateCantidadAcumulada();
		}
	})
	 .fail(function( jqXHR, textStatus, errorThrown ) {
        console.log( "La solicitud a fallado: " +  textStatus);	
	});
}



$(document).on("click", "[button-name=btRemove]", function(event) { 
	
	var id=$(this).closest("div").prop("id");
	var res = id.split("-");
	
	var countTemp=myMap.get(res[0]);
	if(countTemp){
		if(countTemp==1){
			myMap.delete(res[0]);
		}else{
			countTemp-=1;
			myMap.set(res[0],countTemp);
		}
		$(this).closest("div").remove();
	}
	
	updateCantidadAcumulada();
	
});



function addErrorClass(validateClass){
	$(validateClass).each( function( index ) {			
		if(($(this).attr("class").indexOf('select2-container') == -1 && $(this).val().trim() == "") || 
			($(this).attr("class").indexOf('select2-container') != -1 && $(this).prev().val().trim() == ""))	{
			  if(!estado && $(this).is(':visible')) {
				  element = this;
				  estado =  true;
			  }
			  $(this).addClass("error");
		  }
		  else $(this).removeClass("error");
		});
}

function updateCantidadAcumulada(){
	var elements = document.getElementsByClassName("inputCantidad");
	
	var name="";
	var valor=0;
	var contTemp=0;
	for (var i = 0; i < elements.length; i++) {
		name=elements[i].name;
		id=elements[i].id;
		valorTemp=$("input[name="+name+"]").val();
		if(isNaN(valorTemp) || valorTemp=="" ){
			valorTemp=0;
		}
		valor=valor+parseFloat(valorTemp);
		contTemp++
	}
	if(isNaN(valor)){
		totalAcumulado=0;
		count=contTemp;
	}
	else{
		totalAcumulado=valor;
		count=contTemp;
	}
	
}


function changeCantidad(id){
	
	if(parseFloat($("#"+id).val())<=0){
		$("#"+id).val("");
		$("#lblmsgerr").html(A5);
		$.colorbox({inline:true, href:$("#errorPop")});
		updateCantidadAcumulada();
	}else if((parseFloat($("#"+id).val()))>totalGlobal){
		dif=(totalGlobal-parseFloat($("#"+id).val()))*-1;
		dif=dif.toFixed(numberDecimals);
		messageReplace=A4.replace("<diferencia>",dif);
		messageReplace=messageReplace.replace("<Moneda>"," "+$("#psCurrency").text());
		$("#lblmsgerr").html(messageReplace);
		$.colorbox({inline:true, href:$("#errorPop")});
		$("#"+id).val("");
		updateCantidadAcumulada();
	}else{
		updateCantidadAcumulada();
		if(totalAcumulado>totalGlobal){
			
			dif=(totalGlobal-totalAcumulado)*-1;
			dif=dif.toFixed(numberDecimals);
			messageReplace=A4.replace("<diferencia>",dif);
			messageReplace=messageReplace.replace("<Moneda>"," "+$("#psCurrency").text());
			$("#lblmsgerr").html(messageReplace);
			$.colorbox({inline:true, href:$("#errorPop")});
			$("#"+id).val("");
		}
		updateCantidadAcumulada()
	}

}


function focusElement(){
	if(idElementFocus){
		setTimeout('$("#"+idElementFocus).focus();', 500);
	}

}